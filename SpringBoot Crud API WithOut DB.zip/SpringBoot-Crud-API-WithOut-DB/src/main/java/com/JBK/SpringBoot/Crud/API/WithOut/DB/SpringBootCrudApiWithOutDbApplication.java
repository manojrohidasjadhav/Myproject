package com.JBK.SpringBoot.Crud.API.WithOut.DB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootCrudApiWithOutDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootCrudApiWithOutDbApplication.class, args);
	}

}
