package com.JBK.SpringBoot.Crud.API.WithOut.DB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootCrudApiWithOutDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
